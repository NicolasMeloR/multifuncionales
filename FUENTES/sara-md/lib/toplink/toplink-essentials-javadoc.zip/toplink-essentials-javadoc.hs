<?xml version='1.0' ?>
<helpset>

<title>TopLink Essentials Java API Reference</title>

<maps>
  <homeID>overview-summary_html</homeID>

  <mapref location="toplink-essentials-javadoc_map.smp" engine="oracle.help.engine.XMLMapConventionEngine"/>
</maps>

<view>
  <label>Search</label>
  <title>TopLink Essentials Java API Reference</title>
  <type>oracle.help.navigator.searchNavigator.SearchNavigator</type>
  <data engine="oracle.help.engine.SearchEngine">toplink-essentials-javadoc_search.idx</data>
</view>

<view>
  <name>TopLink Essentials Java API Reference</name>
  <label>Contents</label>
  <type>oracle.help.navigator.tocNavigator.TOCNavigator</type>
  <data engine="oracle.help.engine.XMLTOCEngine">toplink-essentials-javadoc_toc.xml</data>
</view>

</helpset>
